document.getElementById('real-input').addEventListener('change', function(e) {
    const file = e.target.files[0];
    const fileNameElement = document.querySelector('.file-name');
    
    if (file) {
        // Actualizar nombre del archivo
        fileNameElement.textContent = file.name;
        
        // Vista previa de imagen (opcional)
        const reader = new FileReader();
        reader.onload = function(event) {
            const preview = document.getElementById('preview');
            preview.src = event.target.result;
            preview.style.display = 'block';
        };
        reader.readAsDataURL(file);
    } else {
        fileNameElement.textContent = 'No hay imagen seleccionada';
        document.getElementById('preview').style.display = 'none';
    }
});

// Activar el input file al hacer clic en el botón
document.querySelector('.img-autor').addEventListener('click', function() {
    document.getElementById('real-input').click();
});