document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.getElementById("login-form");
    const usernameInput = document.getElementById("username");
    const passwordInput = document.getElementById("password");
    const togglePasswordBtn = document.getElementById("toggle-password");
    
    // Cargar usuario guardado
    const savedUser = localStorage.getItem("savedUser");
    if (savedUser) {
        usernameInput.value = savedUser;document.addEventListener("DOMContentLoaded", function () {
            const loginForm = document.getElementById("login-form");
            const usernameInput = document.getElementById("username");
            const passwordInput = document.getElementById("password");
            const togglePasswordBtn = document.getElementById("toggle-password");
            
            // Cargar usuario guardado
            const savedUser = localStorage.getItem("savedUser");
            if (savedUser) {
                usernameInput.value = savedUser;
            }
        
            loginForm.addEventListener("submit", function (event) {
                event.preventDefault();
                const username = usernameInput.value.trim();
                const password = passwordInput.value.trim();
                
                if (username && password) {
                    localStorage.setItem("savedUser", username);
                    alert("Login exitoso");
                    window.location.href = "../menú/index.html"; // Esta línea debe ir después de la alerta
                }
                
            });
        
            togglePasswordBtn.addEventListener("click", function () {
                if (passwordInput.type === "password") {
                    passwordInput.type = "text";
                    togglePasswordBtn.textContent = "👁️";
                } else {
                    passwordInput.type = "password";
                    togglePasswordBtn.textContent = "🙈";
                }
            });
        });
        
    }

    loginForm.addEventListener("submit", function (event) {
        event.preventDefault();
        const username = usernameInput.value;
        const password = passwordInput.value;
        
        if (username && password) {
            localStorage.setItem("savedUser", username);
            alert("Login exitoso");
            // Aquí puedes redirigir a otra página o realizar otra acción
        } else {
            alert("Por favor, completa todos los campos");
        }
    });

    togglePasswordBtn.addEventListener("click", function () {
        if (passwordInput.type === "password") {
            passwordInput.type = "text";
            togglePasswordBtn.textContent = "👁️";
        } else {
            passwordInput.type = "password";
            togglePasswordBtn.textContent = "🙈";
        }
    });
});
