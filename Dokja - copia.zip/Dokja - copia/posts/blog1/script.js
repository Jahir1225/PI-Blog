document.addEventListener('DOMContentLoaded', function () {
    cargarComentarios();
  
    document.getElementById('sendComment').addEventListener('click', guardarComentario);
    document.getElementById('commentInput').addEventListener('keypress', function (event) {
      if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        guardarComentario();
      }
    });
  });
  
  function cargarComentarios() {
    const commentsList = document.getElementById('commentsList');
    commentsList.innerHTML = '';
    const comentarios = JSON.parse(localStorage.getItem('comentariosBlog')) || [];
  
    comentarios.forEach(texto => {
      const commentItem = document.createElement('div');
      commentItem.classList.add('comment-item');
      commentItem.innerHTML = `
        <div class="avatar">U</div>
        <div class="text">${texto}</div>
      `;
      commentsList.appendChild(commentItem);
    });
  }
  
  function guardarComentario() {
    const input = document.getElementById('commentInput');
    const comentario = input.value.trim();
  
    if (comentario) {
      const comentarios = JSON.parse(localStorage.getItem('comentariosBlog')) || [];
      comentarios.push(comentario);
      localStorage.setItem('comentariosBlog', JSON.stringify(comentarios));
      input.value = '';
      cargarComentarios();
    }
  }
  

