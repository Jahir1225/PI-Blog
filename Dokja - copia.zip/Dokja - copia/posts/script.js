const postId = 1; // 🔁 Puedes actualizar dinámicamente según el post que se esté viendo
const userId = 1; // 🔁 Debe ser el ID del usuario logueado

// Mostrar comentarios
async function cargarComentarios() {
    const res = await fetch(`http://localhost:3001/api/comentarios?post_id=${postId}`);
    const data = await res.json();

    const container = document.getElementById("commentsContainer");
    container.innerHTML = "";

    if (data.success && data.comments.length > 0) {
        data.comments.forEach(comment => {
            const div = document.createElement("div");
            div.classList.add("comment");
            div.textContent = `${comment.user_name}: ${comment.content}`;
            container.appendChild(div);
        });
    } else {
        container.innerHTML = "<p>No hay comentarios aún.</p>";
    }
}

// Enviar comentario
async function enviarComentario(content) {
    const res = await fetch("http://localhost:3001/api/comentarios", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            user_id: userId,
            post_id: postId,
            content
        })
    });

    const result = await res.json();
    if (result.success) {
        document.getElementById("comment").value = "";
        cargarComentarios();
    } else {
        alert("❌ No se pudo enviar el comentario.");
    }
}

// Manejadores
document.getElementById("commentForm").addEventListener("submit", e => {
    e.preventDefault();
    const content = document.getElementById("comment").value.trim();
    if (content) enviarComentario(content);
});

document.getElementById("comment").addEventListener("keypress", e => {
    if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        const content = document.getElementById("comment").value.trim();
        if (content) enviarComentario(content);
    }
});

// Cargar al inicio
cargarComentarios();
