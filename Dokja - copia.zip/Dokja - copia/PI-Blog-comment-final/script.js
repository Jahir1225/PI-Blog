document.addEventListener('DOMContentLoaded', function () {
    cargarComentarios();
    document.getElementById('sendComment').addEventListener('click', guardarComentario);
    document.getElementById('commentInput').addEventListener('keypress', function (e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            guardarComentario();
        }
    });
});
function cargarComentarios() {
    const comentarios = JSON.parse(localStorage.getItem('comentariosBlog')) || [];
    const commentsList = document.getElementById('commentsList');
    commentsList.innerHTML = '';
    comentarios.forEach(comentario => {
        const div = document.createElement('div');
        div.classList.add('comment-item');
        div.innerHTML = '<div class="avatar">U</div><div class="text">' + comentario + '</div>';
        commentsList.appendChild(div);
    });
}
function guardarComentario() {
    const input = document.getElementById('commentInput');
    const comentario = input.value.trim();
    if (comentario !== '') {
        const comentarios = JSON.parse(localStorage.getItem('comentariosBlog')) || [];
        comentarios.push(comentario);
        localStorage.setItem('comentariosBlog', JSON.stringify(comentarios));
        input.value = '';
        cargarComentarios();
    }
}
