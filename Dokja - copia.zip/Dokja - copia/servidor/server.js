const express = require('express');
const mysql = require('mysql2'); // <- Solo una vez
const bcrypt = require('bcryptjs');
const cors = require('cors');

const app = express();
const PORT = 3001;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Conectar a la base de datos
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '022006', // <-- Asegurate de que esta contraseña sea la correcta
  database: 'db_blog'
});

connection.connect(err => {
  if (err) {
    console.error('Error al conectar a la base de datos:', err);
    return;
  }
  console.log('Conectado a la base de datos');
});

// Ruta para probar el servidor
app.get('/', (req, res) => {
  res.send('Servidor corriendo en http://localhost:3001');
});

// Ruta para registrar usuario
app.post('/registrar', (req, res) => {
  const { userName, userEmail, userPassword } = req.body;

  if (!userName || !userEmail || !userPassword) {
    return res.status(400).json({ success: false, message: "Faltan datos" });
  }

  const checkEmailQuery = 'SELECT * FROM users WHERE email = ?';
  connection.query(checkEmailQuery, [userEmail], (err, result) => {
    if (err) {
      console.error("Error al verificar el correo:", err);
      return res.status(500).json({ success: false, message: 'Error al verificar el correo electrónico' });
    }

    if (result.length > 0) {
      return res.status(400).json({ success: false, message: 'El correo electrónico ya está registrado' });
    }

    bcrypt.hash(userPassword, 10, (err, hashedPassword) => {
      if (err) {
        console.error("Error al encriptar la contraseña:", err);
        return res.status(500).json({ success: false, message: 'Error al encriptar la contraseña' });
      }

      const insertUserQuery = 'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)';
      connection.query(insertUserQuery, [userName, userEmail, hashedPassword, 'usuario'], (err, result) => {
        if (err) {
          console.error("Error al guardar el usuario en la base de datos:", err);
          return res.status(500).json({ success: false, message: 'Error al guardar el usuario en la base de datos' });
        }

        res.status(201).json({ success: true, message: 'Usuario registrado exitosamente', userId: result.insertId, userName });
      });
    });
  });
});


// 🔹 RUTA PARA GUARDAR COMENTARIO
app.post('/api/comentarios', (req, res) => {
  const { user_id, post_id, content } = req.body;

  if (!user_id || !post_id || !content) {
    return res.status(400).json({ success: false, message: 'Faltan datos para el comentario' });
  }

  const query = 'INSERT INTO comments (user_id, post_id, content) VALUES (?, ?, ?)';
  connection.query(query, [user_id, post_id, content], (err, result) => {
    if (err) {
      console.error('❌ Error al guardar comentario:', err);
      return res.status(500).json({ success: false, message: 'Error al guardar el comentario' });
    }
    res.status(201).json({ success: true, message: 'Comentario guardado', commentId: result.insertId });
  });
});

// 🔹 RUTA PARA OBTENER COMENTARIOS POR POST
app.get('/api/comentarios/:post_id', (req, res) => {
  const postId = req.params.post_id;

  const query = `
    SELECT c.id, c.content, c.created_at, u.name as user_name 
    FROM comments c 
    JOIN users u ON c.user_id = u.id 
    WHERE c.post_id = ? 
    ORDER BY c.created_at DESC
  `;

  connection.query(query, [postId], (err, results) => {
    if (err) {
      console.error('❌ Error al obtener comentarios:', err);
      return res.status(500).json({ success: false, message: 'Error al obtener los comentarios' });
    }
    res.json({ success: true, comentarios: results });
  });
});

// Iniciar el servidor
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});



app.post("/api/comentarios", (req, res) => {
  const { user_id, post_id, content } = req.body;

  if (!user_id || !post_id || !content) {
    return res.status(400).json({ success: false, message: "Faltan datos" });
  }

  const query = "INSERT INTO comments (user_id, post_id, content) VALUES (?, ?, ?)";
  connection.query(query, [user_id, post_id, content], (err, result) => {
    if (err) {
      console.error("Error al insertar comentario:", err);
      return res.status(500).json({ success: false, message: "Error al guardar el comentario" });
    }

    res.status(201).json({ success: true, message: "Comentario guardado", commentId: result.insertId });
  });
});
