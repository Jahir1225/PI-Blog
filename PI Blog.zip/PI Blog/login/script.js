
const form = document.getElementById('registroForm');
form.addEventListener('submit', async (event) => {
    event.preventDefault();  // Evita que el formulario se envíe de la forma tradicional
    
    const correo = document.getElementById('correo').value;
    const password = document.getElementById('password').value;

    const response = await fetch('http://localhost:3001/registrar', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ correo, password })
    });

    const data = await response.json();
    if (data.success) {
        alert('Usuario registrado con éxito');
    } else {
        alert('Error al registrar el usuario');
    }
});
