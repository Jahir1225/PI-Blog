const express = require('express');
const mysql = require('mysql2');
const bcrypt = require('bcryptjs');
const cors = require('cors'); // Agregar esta línea
const app = express();
const PORT = 3001;

app.use(cors()); // Agregar esta línea para habilitar CORS
app.use(express.json()); // Middleware para analizar el cuerpo de las solicitudes

// Conexión a la base de datos MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'blog_db'
});

db.connect(err => {
    if (err) throw err;
    console.log('Conectado a MySQL');
});

// Ruta básica de prueba
app.get('/', (req, res) => {
    res.send('Servidor corriendo en http://localhost:3001');
});

// Ruta para registrar un nuevo usuario
app.post('/registrar', (req, res) => {
    const { username, password } = req.body;

    // Verificar si se recibieron los campos correctamente
    if (!username || !password) {
        return res.status(400).json({ message: 'Username y contraseña son requeridos' });
    }

    app.post('/registrar', (req, res) => {
        const { username, password } = req.body;
    
        if (!username || !password) {
            return res.status(400).json({ message: 'Username y contraseña son requeridos' });
        }
    
        // Verificando los datos recibidos
        console.log('Datos recibidos:', { username, password });
    
        // Encriptar la contraseña
        bcrypt.hash(password, 10, (err, hashedPassword) => {
            if (err) {
                console.log('Error al encriptar la contraseña:', err);
                return res.status(500).json({ message: 'Error al encriptar la contraseña' });
            }
    
            console.log('Contraseña encriptada:', hashedPassword);
    
            // Insertar el usuario en la base de datos
            const query = 'INSERT INTO users (username, password, role) VALUES (?, ?, ?)';
            db.query(query, [username, hashedPassword, 'usuario'], (err, result) => {
                if (err) {
                    console.log('Error al insertar en la base de datos:', err);  // Ver el error detallado
                    return res.status(500).json({ message: 'Error al guardar el usuario en la base de datos' });
                }
    
                // Verificar que la inserción fue exitosa
                console.log('Usuario insertado correctamente:', result);
    
                // Mostrar mensaje de éxito y los datos guardados
                res.status(201).json({ message: 'Usuario registrado exitosamente', userId: result.insertId, username: username });
            });
        });
    });
    

    // Encriptar la contraseña
    bcrypt.hash(password, 10, (err, hashedPassword) => {
        if (err) {
            return res.status(500).json({ message: 'Error al encriptar la contraseña' });
        }

        // Insertar el usuario en la base de datos
        const query = 'INSERT INTO users (username, password, role) VALUES (?, ?, ?)';
        db.query(query, [username, hashedPassword, 'usuario'], (err, result) => {
            if (err) {
                return res.status(500).json({ message: 'Error al guardar el usuario en la base de datos' });
            }

            // Mostrar mensaje de éxito y los datos guardados
            res.status(201).json({ message: 'Usuario registrado exitosamente', userId: result.insertId, username: username });
        });
    });
});


// Levantar el servidor
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
