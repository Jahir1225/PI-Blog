const express = require('express');
const mysql = require('mysql2');
const bcrypt = require('bcryptjs');
const cors = require('cors');
const app = express();
const PORT = 3001;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root', // o tu usuario de MySQL
    password: '', // si no tienes contraseña, déjalo vacío
    database: 'db_blog' // asegúrate de que el nombre sea el correcto
});
connection.query(query, [userName, userEmail, hashedPassword, 'usuario'], (err, result) => {
    if (err) {
        console.error("Error al guardar el usuario en la base de datos:", err);  // Muestra el error completo
        console.error("Error SQL:", err.sqlMessage);  // Muestra el mensaje SQL específico
        return res.status(500).json({ success: false, message: 'Error al guardar el usuario en la base de datos' });
    }

    res.status(201).json({ success: true, message: 'Usuario registrado exitosamente', userId: result.insertId, userName });
});

const checkEmailQuery = 'SELECT * FROM users WHERE email = ?';
connection.query(checkEmailQuery, [userEmail], (err, result) => {
    if (err) {
        console.error("Error al verificar el correo:", err);
        return res.status(500).json({ success: false, message: 'Error al verificar el correo electrónico' });
    }

    if (result.length > 0) {
        return res.status(400).json({ success: false, message: 'El correo electrónico ya está registrado' });
    }

    // Si el correo no existe, continúa con la inserción
    const query = 'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)';
    connection.query(query, [userName, userEmail, hashedPassword, 'usuario'], (err, result) => {
        if (err) {
            console.error("Error al guardar el usuario en la base de datos:", err);
            return res.status(500).json({ success: false, message: 'Error al guardar el usuario en la base de datos' });
        }

        res.status(201).json({ success: true, message: 'Usuario registrado exitosamente', userId: result.insertId, userName });
    });
});

connection.connect(err => {  // Cambié 'db' a 'connection'
    if (err) {
        console.error('Error al conectar a la base de datos:', err);
        return;
    }
    console.log('Conectado a la base de datos');
});

app.get('/', (req, res) => {
    res.send('Servidor corriendo en http://localhost:3001');
});

app.post('/registrar', (req, res) => {
    const { userName, userEmail, userPassword } = req.body;

    if (!userName || !userEmail || !userPassword) {
        return res.status(400).json({ success: false, message: "Faltan datos" });
    }

    bcrypt.hash(userPassword, 10, (err, hashedPassword) => {
        if (err) {
            console.error("Error al encriptar la contraseña:", err);  // Aquí se agrega el log
            return res.status(500).json({ success: false, message: 'Error al encriptar la contraseña' });
        }

        const query = 'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)';
        connection.query(query, [userName, userEmail, hashedPassword, 'usuario'], (err, result) => {
            if (err) {
                console.error("Error al ejecutar la consulta:", err);  // Aquí se agrega el log
                return res.status(500).json({ success: false, message: 'Error al guardar el usuario en la base de datos' });
            }

            res.status(201).json({ success: true, message: 'Usuario registrado exitosamente', userId: result.insertId, userName });
        });
    });
});



app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
