// Configurar IDs simulados (en producción vendrían de sesión)
const post_id = 1; // <-- reemplazá con ID dinámico si es posible
const user_id = 1; // <-- deberías obtener esto desde la sesión del usuario logueado

// Función para enviar el comentario al servidor
async function sendComment(event) {
    event.preventDefault();
    const comment = document.getElementById("comentario").value.trim();
    if (!comment) return;

    try {
        const res = await fetch("http://localhost:3001/api/comentarios", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ content: comment, user_id, post_id })
        });

        const data = await res.json();
        if (data.success) {
            document.getElementById("comentario").value = "";
            await cargarComentarios(); // Recargar los comentarios
        } else {
            alert("❌ Error al guardar el comentario");
        }
    } catch (err) {
        console.error("Error en el fetch:", err);
        alert("❌ No se pudo conectar al servidor");
    }
}

// Escuchar Enter en el input
document.getElementById("comentario").addEventListener("keydown", function (e) {
    if (e.key === "Enter") {
        sendComment(e);
    }
});

// Función para cargar los comentarios desde el backend
async function cargarComentarios() {
    try {
        const res = await fetch(`http://localhost:3001/api/comentarios?post_id=${post_id}`);
        const data = await res.json();

        const container = document.getElementById("commentsContainer") || document.createElement("div");
        container.id = "commentsContainer";
        container.className = "comments-section";
        container.innerHTML = "<h2>Comentarios</h2>";

        if (!data.success || !Array.isArray(data.comentarios)) {
            container.innerHTML += "<p>No hay comentarios disponibles.</p>";
        } else {
            data.comentarios.forEach(c => {
                const div = document.createElement("div");
                div.classList.add("comment");
                div.textContent = `${c.name}: ${c.content}`;
                container.appendChild(div);
            });
        }

        // Asegurarse de que esté en el DOM
        if (!document.getElementById("commentsContainer")) {
            document.body.appendChild(container);
        }

    } catch (err) {
        console.error("Error cargando comentarios:", err);
    }
}

window.addEventListener("DOMContentLoaded", cargarComentarios);

// Crear comentario
app.post('/api/comentarios', async (req, res) => {
    const { user_id, post_id, content } = req.body;
    if (!user_id || !post_id || !content) {
        return res.status(400).json({ success: false, message: "Datos incompletos" });
    }

    try {
        await pool.promise().query(
            "INSERT INTO comments (user_id, post_id, content) VALUES (?, ?, ?)",
            [user_id, post_id, content]
        );
        res.json({ success: true });
    } catch (err) {
        console.error("Error al guardar comentario:", err);
        res.status(500).json({ success: false });
    }
});

// Obtener comentarios de un post
app.get('/api/comentarios', async (req, res) => {
    const post_id = req.query.post_id;
    if (!post_id) return res.status(400).json({ success: false, message: "post_id requerido" });

    try {
        const [rows] = await pool.promise().query(
            `SELECT c.content, u.name 
             FROM comments c 
             JOIN users u ON c.user_id = u.id 
             WHERE c.post_id = ? 
             ORDER BY c.created_at DESC`,
            [post_id]
        );
        res.json({ success: true, comentarios: rows });
    } catch (err) {
        console.error("Error al cargar comentarios:", err);
        res.status(500).json({ success: false });
    }
});

const inputComentario = document.getElementById("inputComentario");
const contenedorComentarios = document.getElementById("contenedorComentarios");

// Cargar comentarios guardados
window.addEventListener('load', () => {
    const comentariosGuardados = JSON.parse(localStorage.getItem('comentariosBlog1')) || [];
    comentariosGuardados.forEach(texto => {
        const div = document.createElement('div');
        div.className = 'comentario';
        div.textContent = texto;
        contenedorComentarios.appendChild(div);
    });
});

// Guardar nuevo comentario
inputComentario.addEventListener("keypress", (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
        event.preventDefault();
        const comentario = inputComentario.value.trim();
        if (comentario) {
            const div = document.createElement('div');
            div.className = 'comentario';
            div.textContent = comentario;
            contenedorComentarios.appendChild(div);

            // Guardarlo en localStorage
            let comentarios = JSON.parse(localStorage.getItem('comentariosBlog1')) || [];
            comentarios.push(comentario);
            localStorage.setItem('comentariosBlog1', JSON.stringify(comentarios));

            inputComentario.value = "";
        }
    }
});



